import MobileLayout from "@/components/layout/MobileLayout";
import { ArrowLeft, MapPin, TrendingUp, ShieldCheck, CheckCircle2, Phone, User, Building2 } from "lucide-react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer";
import { Button } from "@/components/ui/button";

export interface ContactInfo {
  name: string;
  phone: string;
  role?: string;
}

interface CarrierProps {
  title: string;
  subtitle: string;
  heroImage: string;
  tags: string[];
  
  // Basic Info
  leadingIndustry: string;
  area: string;
  // company: string; // Removed per request
  contacts: ContactInfo[];
  address: string;

  // Detailed Content
  intro: string;
  features: { title: string; desc: string }[];
  policies: string[];
}

export default function CarrierTemplate({ data }: { data: CarrierProps }) {
  const [, setLocation] = useLocation();

  return (
    <MobileLayout activeTab="/industry" headerTitle="" hideTabBar={true} showBack={false}>
      <div className="min-h-full bg-slate-50 pb-24 relative animate-in fade-in duration-500 font-sans">
        
        {/* Immersive Hero */}
        <div className="relative h-[42vh] w-full overflow-hidden">
            <img 
                src={data.heroImage} 
                className="w-full h-full object-cover animate-in zoom-in-110 duration-[2s]" 
                alt={data.title} 
            />
            {/* Elegant Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-slate-900/80"></div>
            
            {/* Back Button */}
            <div className="absolute top-6 left-6 z-20">
                <button 
                    onClick={() => setLocation("/industry")}
                    className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white active:scale-95 transition-all hover:bg-white/20"
                >
                    <ArrowLeft className="w-5 h-5" />
                </button>
            </div>

            {/* Title Overlay */}
            <div className="absolute bottom-0 left-0 w-full p-6 pb-12">
                <div className="flex flex-wrap gap-2 mb-3">
                    {data.tags.map((tag, i) => (
                        <span key={i} className="px-3 py-1 bg-white/20 backdrop-blur-md border border-white/10 text-white text-[10px] font-medium tracking-wider uppercase rounded-full">
                            {tag}
                        </span>
                    ))}
                </div>
                <h1 className="text-3xl font-serif text-white mb-1 leading-tight tracking-tight shadow-sm">
                    {data.title}
                </h1>
                <p className="text-white/70 text-xs font-light tracking-wide uppercase">
                    {data.subtitle}
                </p>
            </div>
        </div>

        <div className="px-5 space-y-6 -mt-6 relative z-10">
            
            {/* Info Card - Glassmorphism */}
            <div className="bg-white rounded-2xl shadow-xl shadow-slate-200/50 p-6 border border-slate-100 relative overflow-hidden">
                <div className="flex justify-between items-start gap-6">
                    <div className="flex-1">
                        <div className="text-[10px] text-slate-400 uppercase tracking-widest mb-1.5 font-semibold">Total Area</div>
                        <div className="text-2xl font-serif text-slate-900 font-medium">{data.area}</div>
                    </div>
                    <div className="w-px h-10 bg-slate-100"></div>
                    <div className="flex-[1.5]">
                         <div className="text-[10px] text-slate-400 uppercase tracking-widest mb-1.5 font-semibold">Location</div>
                         <div className="text-xs text-slate-700 leading-snug">{data.address}</div>
                    </div>
                </div>
                
                <div className="mt-5 pt-5 border-t border-slate-100">
                    <div className="text-[10px] text-slate-400 uppercase tracking-widest mb-2 font-semibold">Core Industry</div>
                    <p className="text-sm text-slate-700 font-light leading-relaxed">
                        {data.leadingIndustry}
                    </p>
                </div>
            </div>

            {/* Intro Text */}
            <div className="px-2">
                <p className="text-sm text-slate-600 leading-loose text-justify font-light">
                    {data.intro}
                </p>
            </div>

            {/* Features */}
            <section>
                <SectionHeader title="项目亮点" icon={TrendingUp} />
                <div className="mt-4 grid gap-3">
                    {data.features.map((feature, i) => (
                        <div key={i} className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex gap-4">
                            <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center shrink-0 text-slate-900">
                                <span className="font-serif font-bold italic text-lg">{i + 1}</span>
                            </div>
                            <div>
                                <h3 className="font-bold text-slate-900 text-sm mb-1">{feature.title}</h3>
                                <p className="text-xs text-slate-500 leading-relaxed text-justify">
                                    {feature.desc}
                                </p>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Policies */}
            <section>
                <SectionHeader title="配套政策" icon={ShieldCheck} />
                <div className="mt-4 bg-slate-900 rounded-2xl p-6 text-white relative overflow-hidden">
                    <div className="relative z-10 space-y-4">
                        {data.policies.map((policy, i) => (
                            <div key={i} className="flex items-start gap-3">
                                <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                                <p className="text-xs text-slate-300 leading-relaxed font-light">
                                    {policy}
                                </p>
                            </div>
                        ))}
                    </div>
                    {/* Decorative Elements */}
                    <div className="absolute top-0 right-0 w-40 h-40 bg-white/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
                    <div className="absolute bottom-0 left-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>
                </div>
            </section>

            {/* Space for bottom bar */}
            <div className="h-4"></div>

        </div>
        
        {/* Bottom CTA */}
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/90 backdrop-blur-xl border-t border-slate-100 z-50 safe-area-bottom">
            <Drawer>
                <DrawerTrigger asChild>
                    <Button className="w-full h-12 bg-slate-900 text-white rounded-full font-medium text-sm shadow-xl shadow-slate-900/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2 hover:bg-slate-800">
                        <Phone className="w-4 h-4" />
                        预约考察
                    </Button>
                </DrawerTrigger>
                <DrawerContent className="bg-white rounded-t-[2rem]">
                    <div className="mx-auto w-12 h-1.5 flex-shrink-0 rounded-full bg-slate-200 mt-4 mb-8" />
                    <DrawerHeader className="text-center sm:text-left px-6">
                        <DrawerTitle className="text-xl font-serif text-slate-900">联系预约</DrawerTitle>
                        <DrawerDescription className="text-slate-500 text-xs mt-1">
                            请选择联系人拨打电话进行预约咨询
                        </DrawerDescription>
                    </DrawerHeader>
                    <div className="p-6 pt-2 pb-8 space-y-3">
                        {data.contacts.map((contact, i) => (
                            <a 
                                key={i}
                                href={`tel:${contact.phone}`}
                                className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100 active:bg-slate-100 transition-colors"
                            >
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-700 shadow-sm">
                                        <User className="w-5 h-5" />
                                    </div>
                                    <div>
                                        <div className="font-bold text-slate-900 text-sm">
                                            {contact.name}
                                            {contact.role && <span className="text-xs font-normal text-slate-500 ml-1">({contact.role})</span>}
                                        </div>
                                        <div className="text-xs text-slate-500 font-mono mt-0.5">
                                            {contact.phone}
                                        </div>
                                    </div>
                                </div>
                                <div className="w-10 h-10 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center">
                                    <Phone className="w-5 h-5 fill-current" />
                                </div>
                            </a>
                        ))}
                    </div>
                    <DrawerFooter className="pt-2 px-6 pb-8">
                        <DrawerClose asChild>
                            <Button variant="outline" className="w-full h-12 rounded-full border-slate-200 text-slate-600">取消</Button>
                        </DrawerClose>
                    </DrawerFooter>
                </DrawerContent>
            </Drawer>
        </div>

      </div>
    </MobileLayout>
  );
}

function SectionHeader({ title, icon: Icon }: any) {
    return (
        <div className="flex items-center gap-2 mb-4 px-1">
            <div className="w-1 h-4 bg-slate-900 rounded-full"></div>
            <h2 className="text-base font-bold text-slate-900 tracking-tight">{title}</h2>
        </div>
    )
}
