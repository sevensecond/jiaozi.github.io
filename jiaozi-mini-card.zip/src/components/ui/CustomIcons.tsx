import { cn } from "@/lib/utils";
import { 
  ContactRound, 
  Building2, 
  Landmark, 
  Briefcase, 
  Handshake, 
  type LucideIcon 
} from "lucide-react";

interface IconProps extends React.ComponentProps<LucideIcon> {
  isActive?: boolean;
}

// Wrapper to create consistent elegant style
const CreateIcon = (Icon: LucideIcon) => {
  return ({ isActive, className, ...props }: IconProps) => (
    <div className="relative flex items-center justify-center">
      <Icon
        strokeWidth={isActive ? 2.5 : 1.5}
        className={cn(
          "w-6 h-6 transition-all duration-300",
          isActive ? "scale-110" : "scale-100",
          className
        )}
        {...props}
      />
      {isActive && (
        <div className="absolute inset-0 bg-current opacity-10 blur-md rounded-full -z-10 scale-150" />
      )}
    </div>
  );
};

export const IconCard = CreateIcon(ContactRound);
export const IconIndustry = CreateIcon(Building2);
export const IconCulture = CreateIcon(Landmark);
export const IconGroup = CreateIcon(Briefcase);
export const IconCooperation = CreateIcon(Handshake);
