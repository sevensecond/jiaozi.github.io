import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import TabBar from "./TabBar";
import { MoreHorizontal, Disc, ChevronLeft } from "lucide-react";
import { useLocation } from "wouter";

interface MobileLayoutProps {
  children: ReactNode;
  activeTab?: string;
  hideTabBar?: boolean;
  headerTitle?: string;
  showBack?: boolean;
}

export default function MobileLayout({ 
  children, 
  activeTab, 
  hideTabBar = false,
  headerTitle = "交子金融梦工场",
  showBack = false
}: MobileLayoutProps) {
  const [, setLocation] = useLocation();
  return (
    <div className="min-h-screen w-full bg-gray-100 flex justify-center items-center font-sans">
      {/* Phone Frame Mockup */}
      <div className="w-full max-w-[430px] h-[100dvh] bg-background relative shadow-2xl overflow-hidden flex flex-col">
        
        {/* WeChat Mini Program Header Mockup */}
        <div className="h-12 bg-white/90 backdrop-blur-md flex items-center justify-center px-4 shrink-0 border-b border-gray-100 relative z-50">
           {showBack && (
              <button 
                onClick={() => window.history.back()}
                className="absolute left-3 top-1/2 -translate-y-1/2 p-1 active:bg-gray-100 rounded-full transition-colors"
              >
                 <ChevronLeft className="w-5 h-5 text-black" />
              </button>
           )}
           {/* Capsule Button Mockup */}
           <div className="absolute right-3 top-1/2 -translate-y-1/2 w-[87px] h-[32px] bg-white/60 border border-gray-200 rounded-full flex items-center justify-between px-3 box-content">
              <MoreHorizontal className="w-5 h-5 text-black" />
              <div className="w-[1px] h-4 bg-gray-200 mx-1"></div>
              <Disc className="w-5 h-5 text-black" />
           </div>
           
           <h1 className="text-[17px] font-medium text-black">{headerTitle}</h1>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden relative bg-[#F5F7FA]">
           {children}
        </div>

        {/* Tab Bar */}
        {!hideTabBar && <TabBar activeTab={activeTab} />}
      </div>
    </div>
  );
}
