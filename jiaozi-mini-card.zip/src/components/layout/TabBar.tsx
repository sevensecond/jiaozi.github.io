import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { IconCard, IconIndustry, IconCulture, IconGroup, IconCooperation } from "@/components/ui/CustomIcons";

interface TabBarProps {
  activeTab?: string;
}

export default function TabBar({ activeTab }: TabBarProps) {
  const [location] = useLocation();
  const currentPath = activeTab || location;

  const tabs = [
    { id: "card", label: "名片", path: "/", icon: IconCard },
    { id: "industry", label: "产业运营", path: "/industry", icon: IconIndustry },
    { id: "culture", label: "文化服务", path: "/culture", icon: IconCulture },
    { id: "group", label: "公司简介", path: "/group", icon: IconGroup },
    { id: "cooperation", label: "合作共赢", path: "/cooperation", icon: IconCooperation },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50">
      {/* Gradient Mask for content fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white via-white/80 to-transparent pointer-events-none"></div>
      
      {/* Floating Capsule Bar */}
      <div className="relative mx-auto mb-6 w-[95%] max-w-[390px] h-[72px] bg-white/90 backdrop-blur-3xl border border-white/60 shadow-[0_8px_32px_0_rgba(31,38,135,0.1)] rounded-[24px] flex items-center justify-between px-2 ring-1 ring-black/5">
        {tabs.map((tab) => {
          const isActive = currentPath === tab.path || (currentPath.startsWith(tab.path) && tab.path !== "/");
          
          return (
            <Link href={tab.path} key={tab.id} className="flex-1 h-full">
              <div className="group flex flex-col items-center justify-center h-full gap-[4px] cursor-pointer relative">
                {/* Active Background Indicator - Subtle glow */}
                {isActive && (
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 bg-amber-500/5 rounded-full -z-10 animate-in fade-in duration-300"></div>
                )}
                
                {/* Icon */}
                <div className={cn(
                  "p-1 rounded-xl transition-all duration-300 ease-out relative",
                  isActive 
                    ? "text-amber-600 translate-y-[-2px]" 
                    : "text-gray-400 group-hover:text-gray-600"
                )}>
                  <tab.icon
                    className="w-[24px] h-[24px]"
                    isActive={isActive}
                  />
                  
                  {/* Active Dot Floating */}
                   {isActive && (
                     <div className="absolute -top-1 right-0 w-1.5 h-1.5 bg-amber-500 rounded-full border border-white animate-in zoom-in duration-300"></div>
                   )}
                </div>
                
                {/* Label */}
                <span className={cn(
                  "text-[10px] font-medium leading-none tracking-wide transition-all duration-300",
                  isActive 
                    ? "text-gray-900 translate-y-[-2px] font-bold" 
                    : "text-gray-400 group-hover:text-gray-500"
                )}>
                  {tab.label}
                </span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
