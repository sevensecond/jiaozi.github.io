import MobileLayout from "@/components/layout/MobileLayout";
import { ArrowRight, Phone, Users, Monitor, ShieldCheck, MapPin } from "lucide-react";
import { cn } from "@/lib/utils";
import tianfu9Img from "@/assets/tianfu-9.jpg";

export default function Venue() {
  const venues = [
    { 
        name: "国际路演大厅", 
        capacity: "150-200人", 
        tags: ["LED大屏", "专业音响", "同声传译"],
        desc: "适合举办大型发布会、投融资路演、行业论坛等活动。",
        image: "bg-indigo-900" // Placeholder color
    },
    { 
        name: "多功能会议室", 
        capacity: "50-80人", 
        tags: ["灵活布局", "高清投影"],
        desc: "适合企业培训、闭门会议、沙龙分享。",
        image: "bg-slate-800"
    },
    { 
        name: "VIP会客厅", 
        capacity: "10-20人", 
        tags: ["私密性强", "高端茶歇"],
        desc: "适合商务洽谈、高层接待。",
        image: "bg-slate-700"
    },
  ];

  return (
    <MobileLayout activeTab="/venue" headerTitle="场地服务" hideTabBar={true} showBack={true}>
      <div className="min-h-full bg-slate-50 pb-12">
        
        {/* Header */}
        <div className="bg-white px-6 pt-6 pb-6 border-b border-slate-100 sticky top-0 z-10">
            <h1 className="text-2xl font-serif text-slate-900 mb-1">专业商务空间</h1>
            <p className="text-xs text-slate-500">位于成都金融城核心区，满足多元化商务需求</p>
        </div>

        <div className="px-6 py-6 space-y-6">
            
            {/* Venue List */}
            <div className="space-y-6">
                {venues.map((venue, idx) => (
                    <VenueCard key={idx} data={venue} />
                ))}
            </div>

            {/* Service Guarantee */}
            <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm">
                <h3 className="font-bold text-slate-900 text-sm mb-4">配套服务</h3>
                <div className="grid grid-cols-3 gap-4">
                    <ServiceItem icon={Monitor} label="视听设备" />
                    <ServiceItem icon={ShieldCheck} label="安保服务" />
                    <ServiceItem icon={Users} label="会务支持" />
                </div>
            </div>

            {/* Booking Contact */}
            <div className="bg-indigo-900 rounded-2xl p-6 text-white shadow-xl shadow-indigo-900/20 relative overflow-hidden">
                <div className="relative z-10">
                    <h3 className="text-lg font-bold mb-2">预定咨询</h3>
                    <p className="text-indigo-200 text-xs mb-6 max-w-[200px]">
                        如需预定场地或咨询档期，请直接联系我们的会务经理。
                    </p>
                    <button className="bg-white text-indigo-900 w-full h-12 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-50 transition-colors active:scale-95">
                        <Phone className="w-4 h-4" />
                        028-6666 8888
                    </button>
                </div>
                {/* Decor */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/20 rounded-full blur-2xl translate-x-1/2 -translate-y-1/2"></div>
            </div>

        </div>

      </div>
    </MobileLayout>
  );
}

function VenueCard({ data }: any) {
    return (
        <div className="bg-white rounded-[1.5rem] overflow-hidden shadow-sm border border-slate-100 group">
            {/* Image Area */}
            <div className={cn("h-40 w-full relative", data.image)}>
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
                <div className="absolute bottom-4 left-4">
                    <h3 className="text-white text-lg font-bold shadow-sm">{data.name}</h3>
                </div>
            </div>
            
            <div className="p-5">
                <div className="flex flex-wrap gap-2 mb-3">
                    <span className="px-2 py-1 bg-indigo-50 text-indigo-600 text-[10px] font-bold rounded-md">
                        {data.capacity}
                    </span>
                    {data.tags.map((tag: string, i: number) => (
                        <span key={i} className="px-2 py-1 bg-slate-100 text-slate-500 text-[10px] rounded-md">
                            {tag}
                        </span>
                    ))}
                </div>
                <p className="text-xs text-slate-500 leading-relaxed text-justify">
                    {data.desc}
                </p>
            </div>
        </div>
    )
}

function ServiceItem({ icon: Icon, label }: any) {
    return (
        <div className="flex flex-col items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-600">
                <Icon className="w-5 h-5" />
            </div>
            <span className="text-[10px] text-slate-500">{label}</span>
        </div>
    )
}
