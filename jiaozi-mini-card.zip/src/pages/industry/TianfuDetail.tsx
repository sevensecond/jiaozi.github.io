import CarrierTemplate from "@/components/industry/CarrierTemplate";
import heroImg from "@/assets/tianfu-9.jpg";

export default function TianfuDetail() {
  const data = {
    title: "天府国际金融中心9号楼",
    subtitle: "Tianfu International Finance Center Building 9",
    heroImage: heroImg,
    tags: ["金融CBD", "旗舰空间", "成熟期企业"],
    
    // Data from Image
    leadingIndustry: "区块链、大数据、云计算、人工智能、物联网等新一代信息技术",
    area: "0.7万m²",
    
    contacts: [
        { name: "杨女士", phone: "15108332728" }
    ],
    address: "成都市高新区天府大道966号9号楼",

    intro: "交子金融梦工场·天府国际金融中心9号楼地处西部首位金融CBD，是交子金融梦工场首个旗舰空间，也是成都金融科技创新文化的发源地。项目重点聚焦成熟期的金融科技企业、重大金融配套设施及省市重大金融科技功能性平台项目。于2016年11月正式投运，已成为国内领军型高品质科创空间。",
    
    features: [
        { title: "核心区位", desc: "位于金融城核心区域，距离地铁1号线金融城站仅160米，临近9号线心岛站、18号线锦城广场东站，交通极其便利。" },
        { title: "品质配套", desc: "拥享花园式低密生态办公环境。楼内配置高速电梯、中央空调、智能安防；园区配套银行、食堂、咖啡厅、超市等，满足商务与生活需求。" },
        { title: "定制招商", desc: "针对行业影响力团队或核心技术前瞻性团队，采取'一企一策'定制招商政策，提供专属优惠方案。" }
    ],
    policies: [
        "根据企业资质匹配产业政策，享受产业折扣",
        "根据企业签约金额，匹配规模客户优惠",
        "针对优质团队提供'一企一策'定制优惠方案"
    ]
  };

  return <CarrierTemplate data={data} />;
}
