import CarrierTemplate from "@/components/industry/CarrierTemplate";
import heroImg from "@/assets/fintech-center.jpg";

export default function FintechDetail() {
  const data = {
    title: "交子金融科技中心",
    subtitle: "Jiaozi Fintech Center",
    heroImage: heroImg,
    tags: ["国家级孵化器", "产学研平台", "成长期企业"],
    
    // Data from Image
    leadingIndustry: "区块链、大数据、云计算、人工智能、物联网等新一代信息技术",
    area: "5.2万m²",
    
    contacts: [
        { name: "吴女士", phone: "13111881229" }
    ],
    address: "成都市高新区天府大道北段1677号",

    intro: "交子金融科技中心是交子金融梦工场二期项目，已获批'国家级科技企业孵化器'。项目重点聚焦区块链、大数据、云计算、人工智能、物联网等领域的金融科技企业，汇聚清华大学成都高质量发展研究院、复旦大学西部国际金融研究院等4个产学研合作平台，以及天府金融风险监测大脑等重大项目。",
    
    features: [
        { title: "产学研聚集", desc: "聚集清华、复旦等顶尖高校产学研平台，构建'产学研用投'一体化创新生态。" },
        { title: "灵活空间", desc: "提供工位出租（满足6-290人）及整层大面积办公空间，适应不同规模企业需求。" },
        { title: "全面服务", desc: "提供投融资指导、技术咨询、创业辅导、人力资源等全方位中介服务，配套餐厅、咖啡厅等生活设施。" }
    ],
    policies: [
        "根据企业资质匹配产业政策折扣",
        "根据签约金额与期限匹配规模及租期优惠",
        "依据签约金额赠送车位及会议室使用时长"
    ]
  };

  return <CarrierTemplate data={data} />;
}
