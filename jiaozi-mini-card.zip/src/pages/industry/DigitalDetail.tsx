import CarrierTemplate from "@/components/industry/CarrierTemplate";
import heroImg from "@/assets/digital-center.jpg";

export default function DigitalDetail() {
  const data = {
    title: "交子金融梦工场·四期",
    subtitle: "Jiaozi Fintech Dreamworks Phase 4",
    heroImage: heroImg,
    tags: ["基金+科技", "新质生产力", "双地铁交汇"],
    
    // Data from Image
    leadingIndustry: "重点汇聚以金融科技为牵引的新质生产力企业以及政府和国资类基金，搭建政府和国资类基金集聚发展平台，打造以金融科技为牵引的新质生产力聚集区。",
    area: "7.8万m²",
    
    contacts: [
        { name: "杨女士", phone: "15108332728", role: "产业" },
        { name: "赵先生", phone: "13880040930", role: "商业" }
    ],
    address: "成都市锦江区泰治路288号、188号",

    intro: "梦工场四期项目位于锦江区，是交子公园金融商务区锦江片区首个呈现的产业载体。项目定位为集研发设计、创新转化、产融对接、场景营造、社区服务于一体的'基金+科技'产业总部基地。",
    
    features: [
        { title: "产业集群", desc: "打造具有独特核心竞争力的金融科技产业集群，推动金融高质量发展，助力共建西部金融中心。" },
        { title: "商业配套", desc: "配备精选零售、臻享美食、科技生活等功能配套，分区设置2个共约2000平米的智慧餐厅。" },
        { title: "双铁交汇", desc: "毗邻地铁6号线/9号线金融城东站，双地铁交汇，交通极其便捷。" }
    ],
    policies: [
        "根据企业资质与签约金额匹配产业折扣与规模优惠",
        "根据装修需求匹配装修免租期",
        "针对政府重大项目或前瞻性团队提供'一企一策'定制招商政策"
    ]
  };

  return <CarrierTemplate data={data} />;
}
