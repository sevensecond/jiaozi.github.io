import CarrierTemplate from "@/components/industry/CarrierTemplate";
import heroImg from "@/assets/maitian.jpg";

export default function MaitianDetail() {
  const data = {
    title: "金融麦田",
    subtitle: "Financial Wheat Field",
    heroImage: heroImg,
    tags: ["民营经济基地", "科创研发", "数字人民币"],
    
    // Data from Image
    leadingIndustry: "科技金融创新研发与应用，准独角兽企业、重大产业项目和民营企业",
    area: "3.8万m²",
    
    contacts: [
        { name: "周女士", phone: "13709007487" }
    ],
    address: "成都市高新区锦云东三巷1号",

    intro: "交子金融梦工场·金融麦田聚焦科技金融创新研发与应用，重点集聚准独角兽企业、重大产业项目和民营企业。作为成都市民营经济发展促进中心驻地，项目分为四大组团：A组团融资服务基地（上交所西部基地），B组团金融科技聚集，C组团民营经济服务，D组团数字人民币研发应用。",
    
    features: [
        { title: "功能组团", desc: "A/B/C/D四大组团功能明确，涵盖融资服务、金融科技、民营经济服务及数字人民币研发。" },
        { title: "生态办公", desc: "毗邻交子公园，享受低密生态办公环境，交通便捷（近地铁孵化园站/心岛站）。" },
        { title: "高端配套", desc: "配置餐厅、咖啡厅、超市等生活配套，提供全方位创业辅导与投融资服务。" }
    ],
    policies: [
        "根据企业资质与签约金额匹配产业折扣与规模优惠",
        "根据装修需求提供装修免租期",
        "依据签约金额赠送车位及会议室使用时长"
    ]
  };

  return <CarrierTemplate data={data} />;
}
