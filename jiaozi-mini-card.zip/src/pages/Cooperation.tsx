import MobileLayout from "@/components/layout/MobileLayout";
import { Building2, Mail, Phone, ArrowUpRight, MessageSquare, Handshake, Newspaper } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Cooperation() {
  return (
    <MobileLayout activeTab="/cooperation" headerTitle="" hideTabBar={false}>
      <div className="min-h-full bg-slate-50 pb-20">
        
        {/* Header */}
        <div className="bg-slate-900 pt-16 pb-20 px-6 relative overflow-hidden">
            <div className="relative z-10">
                <h1 className="text-3xl font-serif text-white mb-3">商务合作</h1>
                <p className="text-slate-400 text-xs font-light max-w-[80%] leading-relaxed">
                    我们期待与各界伙伴携手，在产业运营、文化展陈、活动策划等领域共创价值。
                </p>
            </div>
            {/* Abstract Shapes */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2"></div>
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl -translate-x-1/2 translate-y-1/2"></div>
        </div>

        <div className="px-5 -mt-10 relative z-10 space-y-5">
            
            {/* Main Contact Card */}
            <div className="bg-white rounded-2xl p-6 shadow-xl shadow-slate-200/50 border border-slate-100">
                <h2 className="text-sm font-bold text-slate-900 mb-6 flex items-center gap-2">
                    <Handshake className="w-4 h-4 text-blue-600" />
                    合作联系
                </h2>
                
                <div className="space-y-6">
                    <ContactItem 
                        icon={Building2}
                        title="产业合作"
                        desc="入驻咨询 / 孵化器合作 / 场地租赁"
                        contact="李经理"
                        phone="028-8888 6666"
                        color="bg-blue-50 text-blue-600"
                    />
                    <div className="h-px bg-slate-50 w-full"></div>
                    <ContactItem 
                        icon={Newspaper}
                        title="品牌与媒体"
                        desc="媒体采访 / 品牌联名 / 活动支持"
                        contact="王女士"
                        phone="028-8888 9999"
                        color="bg-purple-50 text-purple-600"
                    />
                    <div className="h-px bg-slate-50 w-full"></div>
                    <ContactItem 
                        icon={MessageSquare}
                        title="文博与社教"
                        desc="研学定制 / 巡展合作 / 志愿者招募"
                        contact="陈老师"
                        phone="028-6188 7777"
                        color="bg-orange-50 text-orange-600"
                    />
                </div>
            </div>

            {/* General Info */}
            <div className="grid grid-cols-2 gap-3">
                <InfoCard 
                    label="官方邮箱" 
                    value="bd@jiaozi.com" 
                    icon={Mail} 
                />
                <InfoCard 
                    label="总部地址" 
                    value="天府国际金融中心" 
                    icon={Building2} 
                />
            </div>

            {/* Map Placeholder */}
            <div className="bg-white rounded-2xl p-2 shadow-sm border border-slate-100">
                <div className="w-full h-40 bg-slate-100 rounded-xl flex items-center justify-center relative overflow-hidden group">
                    {/* Mock Map Pattern */}
                    <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#cbd5e1_1px,transparent_1px)] [background-size:16px_16px]"></div>
                    <div className="text-slate-400 text-xs font-medium flex items-center gap-1.5 z-10">
                        <ArrowUpRight className="w-4 h-4" />
                        查看导航地图
                    </div>
                </div>
            </div>

        </div>

      </div>
    </MobileLayout>
  );
}

function ContactItem({ icon: Icon, title, desc, contact, phone, color }: any) {
    return (
        <div className="flex items-start gap-4">
            <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center shrink-0", color)}>
                <Icon className="w-5 h-5" />
            </div>
            <div className="flex-1">
                <div className="flex justify-between items-start mb-1">
                    <h3 className="text-sm font-bold text-slate-900">{title}</h3>
                    <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-100">
                        <Phone className="w-3 h-3 text-slate-400" />
                        <span className="text-xs font-mono font-medium text-slate-700">{phone}</span>
                    </div>
                </div>
                <p className="text-[11px] text-slate-400 mb-2">{desc}</p>
                <div className="text-xs text-slate-600 font-medium">联系人：{contact}</div>
            </div>
        </div>
    )
}

function InfoCard({ label, value, icon: Icon }: any) {
    return (
        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex flex-col gap-3">
            <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-slate-500">
                <Icon className="w-4 h-4" />
            </div>
            <div>
                <div className="text-[10px] text-slate-400 mb-0.5">{label}</div>
                <div className="text-sm font-bold text-slate-900">{value}</div>
            </div>
        </div>
    )
}
