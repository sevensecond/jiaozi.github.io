import MobileLayout from "@/components/layout/MobileLayout";
import bgImg from "@/assets/bg-texture-elegant.jpg";
import { Link } from "wouter";
import { ArrowUpRight, Building, Landmark } from "lucide-react";

export default function Group() {
  return (
    <MobileLayout activeTab="/group" headerTitle="" hideTabBar={false}>
      <div className="min-h-screen relative overflow-hidden font-sans text-slate-800 pb-24 bg-slate-50">
        
        {/* Texture Background Layer */}
        <div className="absolute inset-0 z-0">
            <img src={bgImg} alt="Texture" className="w-full h-full object-cover opacity-10" />
            <div className="absolute inset-0 bg-gradient-to-b from-white via-white/80 to-slate-50"></div>
        </div>

        {/* Artistic Header Section */}
        <div className="relative z-10 px-8 pt-12 pb-8">
           <div className="w-10 h-1 bg-amber-500 mb-6 rounded-full"></div>
           
           <h1 className="text-4xl font-serif text-slate-900 leading-tight tracking-tight mb-4">
             传承<span className="text-amber-600 italic">交子</span><br/>
             <span className="font-light text-slate-600">赋能金融未来</span>
           </h1>
           
           <p className="text-xs text-slate-500 leading-loose max-w-[90%] tracking-wide">
             作为成都交子金控集团全资子公司，我们致力于打造全国领先的金融科技产业集聚平台，构建产融结合的创新生态。
           </p>
        </div>

        {/* Elegant Stats Grid */}
        <div className="relative z-10 px-6 mb-10">
           <div className="grid grid-cols-2 gap-4">
              <StatItem num="17" unit="万㎡" label="运营面积" />
              <StatItem num="280" unit="+" label="孵化企业" />
              <StatItem num="20" unit="+" label="展陈项目" />
              <StatItem num="500" unit="+" label="承办活动" />
           </div>
        </div>

        {/* Business Philosophy - Glass Cards */}
        <div className="relative z-10 px-6 space-y-5">
           <div className="flex items-center justify-between px-1 mb-2">
              <span className="text-[10px] uppercase tracking-widest font-bold text-slate-400">Core Business</span>
              <div className="h-px flex-1 bg-slate-200 ml-4"></div>
           </div>

           <Link href="/industry">
              <BusinessCard 
                  title="产业运营"
                  subtitle="Industrial Operation"
                  desc="依托四大高品质科创空间，构建'产学研用投'一体化金融科技生态圈。"
                  icon={Building}
              />
           </Link>

           <Link href="/culture">
              <BusinessCard 
                  title="文化服务"
                  subtitle="Cultural Service"
                  desc="运营全国首家金融博物馆，提供专业的展陈策划、会务研学及文创服务。"
                  icon={Landmark}
              />
           </Link>
        </div>

      </div>
    </MobileLayout>
  );
}

function StatItem({ num, unit, label }: any) {
    return (
        <div className="flex flex-col items-start p-4 bg-white/60 backdrop-blur-sm rounded-2xl border border-white/50 shadow-sm">
            <div className="flex items-baseline gap-1 mb-1 font-serif">
                <span className="text-3xl font-bold text-slate-900">{num}</span>
                <span className="text-xs text-amber-600 font-medium">{unit}</span>
            </div>
            <span className="text-[10px] text-slate-400 uppercase tracking-wider">{label}</span>
        </div>
    )
}

function BusinessCard({ title, subtitle, desc, icon: Icon }: any) {
    return (
        <div className="group relative bg-white rounded-2xl border border-slate-100 p-6 cursor-pointer transition-all duration-500 shadow-[0_4px_20px_-12px_rgba(0,0,0,0.05)] hover:shadow-lg hover:-translate-y-1 active:scale-[0.98]">
            <div className="flex justify-between items-start mb-4">
                <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center text-slate-700 group-hover:bg-slate-900 group-hover:text-white transition-colors duration-300">
                    <Icon className="w-6 h-6" strokeWidth={1.5} />
                </div>
                <div className="w-8 h-8 rounded-full flex items-center justify-center border border-slate-100 group-hover:border-amber-200 transition-colors">
                    <ArrowUpRight className="w-4 h-4 text-slate-300 group-hover:text-amber-500" />
                </div>
            </div>
            
            <h3 className="text-lg font-bold text-slate-900 mb-1">{title}</h3>
            <p className="text-[10px] uppercase tracking-wider text-slate-400 font-medium mb-3">{subtitle}</p>
            <p className="text-xs text-slate-500 leading-relaxed text-justify group-hover:text-slate-700">
                {desc}
            </p>
        </div>
    )
}
