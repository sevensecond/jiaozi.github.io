import MobileLayout from "@/components/layout/MobileLayout";
import { 
  Share2, 
  Download, 
  Navigation, 
  QrCode, 
  WalletCards, 
  Phone,
  Building2,
  MapPin,
  Calendar,
  Armchair
} from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import avatarImg from "@/assets/avatar.jpg";
import { cn } from "@/lib/utils";

export default function Home() {
  const [, setLocation] = useLocation();
  const handleAction = (action: string) => {
    if (action === "visit") {
        setLocation("/visit");
        return;
    }
    if (action === "venue") {
        setLocation("/venue");
        return;
    }
    toast.success(`已触发操作: ${action}`);
  };

  return (
    <MobileLayout activeTab="/" headerTitle="" hideTabBar={false}>
      <div className="relative min-h-full pb-28 bg-slate-50">
        
        {/* Subtle Background */}
        <div className="absolute top-0 left-0 right-0 h-[300px] bg-gradient-to-b from-slate-200/50 to-transparent pointer-events-none z-0"></div>

        <div className="relative z-10 px-6 pt-8 space-y-6">
          
          {/* Brand Header */}
          <div className="flex items-center justify-between px-1">
              <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-slate-900 rounded-lg flex items-center justify-center text-white font-serif font-bold italic">J</div>
                  <span className="text-sm font-bold text-slate-900 tracking-tight">JIAOZI FINTECH</span>
              </div>
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
          </div>

          {/* Premium Business Card */}
          <div className="relative w-full aspect-[1.75/1] rounded-[1.5rem] overflow-hidden shadow-[0_20px_40px_-12px_rgba(15,23,42,0.2)] group perspective-1000">
            <div className="absolute inset-0 bg-slate-900 transition-transform duration-700 preserve-3d group-hover:rotate-x-2">
               {/* Texture */}
               <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay"></div>
               <div className="absolute -top-[50%] -left-[50%] w-[200%] h-[200%] bg-[radial-gradient(circle,rgba(255,255,255,0.03)_0%,transparent_60%)]"></div>
               
               {/* Content */}
               <div className="relative z-10 h-full p-6 flex flex-col justify-between">
                  <div className="flex justify-between items-start">
                      <div>
                          <h2 className="text-2xl font-serif text-white tracking-wide">某某</h2>
                          <p className="text-xs text-slate-400 font-medium tracking-widest uppercase mt-1">招商运营总监</p>
                      </div>
                      <div className="w-12 h-12 rounded-full border-2 border-slate-700 p-0.5">
                          <img src={avatarImg} alt="Avatar" className="w-full h-full object-cover rounded-full" />
                      </div>
                  </div>

                  <div className="space-y-2">
                      <div className="flex items-center gap-2 text-slate-300">
                          <Building2 className="w-3.5 h-3.5 text-amber-500" />
                          <span className="text-[10px] font-light tracking-wide">成都金融梦工场投资管理有限公司</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-300">
                          <MapPin className="w-3.5 h-3.5 text-amber-500" />
                          <span className="text-[10px] font-light tracking-wide">成都市交子金融科技中心A座</span>
                      </div>
                      <div className="flex items-center gap-2 text-white mt-1">
                          <Phone className="w-3.5 h-3.5 text-amber-500" />
                          <span className="text-sm font-mono font-bold tracking-wider">188 8888 8888</span>
                      </div>
                  </div>
               </div>
            </div>
          </div>

          {/* Action Bar */}
          <div className="grid grid-cols-4 gap-3">
             <ActionBtn icon={Share2} label="发名片" onClick={() => handleAction("分享名片")} />
             <ActionBtn icon={Download} label="存手机" onClick={() => handleAction("保存号码")} />
             <ActionBtn icon={QrCode} label="名片码" onClick={() => handleAction("查看名片码")} />
             <ActionBtn icon={Phone} label="呼叫" active onClick={() => handleAction("拨打电话")} />
          </div>

          {/* Quick Services */}
          <div className="pt-2">
             <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 px-1">Quick Access</h3>
             <div className="grid grid-cols-2 gap-3">
                <ServiceTile 
                   icon={Navigation}
                   title="一键导航" 
                   desc="前往园区"
                   color="text-blue-600 bg-blue-50"
                />
                <ServiceTile 
                   icon={WalletCards}
                   title="名片夹" 
                   desc="我的收藏"
                   color="text-indigo-600 bg-indigo-50"
                />
                <ServiceTile 
                   icon={Calendar}
                   title="参观预约" 
                   desc="预约博物馆"
                   color="text-amber-600 bg-amber-50"
                   onClick={() => handleAction("visit")}
                />
                <ServiceTile 
                   icon={Armchair}
                   title="场地预定" 
                   desc="路演厅/会议室"
                   color="text-purple-600 bg-purple-50"
                   onClick={() => handleAction("venue")}
                />
             </div>
          </div>

        </div>
      </div>
    </MobileLayout>
  );
}

function ActionBtn({ icon: Icon, label, onClick, active }: any) {
   return (
      <button 
         onClick={onClick}
         className={cn(
            "flex flex-col items-center justify-center gap-2 py-3 rounded-2xl transition-all active:scale-95",
            active ? "bg-slate-900 text-white shadow-lg shadow-slate-900/20" : "bg-white text-slate-500 shadow-sm border border-slate-100"
         )}
      >
         <Icon className="w-5 h-5" strokeWidth={1.5} />
         <span className="text-[10px] font-medium">{label}</span>
      </button>
   )
}

function ServiceTile({ icon: Icon, title, desc, color, onClick }: any) {
   return (
      <div onClick={onClick} className="flex items-center gap-3 p-4 rounded-2xl bg-white border border-slate-100 shadow-sm hover:shadow-md transition-all active:scale-[0.98] cursor-pointer">
         <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center shrink-0", color)}>
            <Icon className="w-5 h-5" strokeWidth={1.5} />
         </div>
         <div>
            <h4 className="text-sm font-bold text-slate-900">{title}</h4>
            <p className="text-[10px] text-slate-400">{desc}</p>
         </div>
      </div>
   )
}
