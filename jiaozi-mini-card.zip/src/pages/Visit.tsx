import MobileLayout from "@/components/layout/MobileLayout";
import { Clock, MapPin, Calendar, Smartphone, Info, ArrowRight, Phone } from "lucide-react";
import museumImg from "@/assets/museum.jpg";

export default function Visit() {
  return (
    <MobileLayout activeTab="/visit" headerTitle="参观指南" hideTabBar={true} showBack={true}>
      <div className="min-h-full bg-white pb-12">
        
        {/* Hero Image */}
        <div className="relative h-56 w-full">
            <img src={museumImg} className="w-full h-full object-cover" alt="Museum" />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/20 to-transparent"></div>
            <div className="absolute bottom-6 left-6 right-6">
                <h1 className="text-3xl font-serif text-white mb-2">预约参观</h1>
                <p className="text-white/80 text-xs font-light">探索金融历史，感受交子文化</p>
            </div>
        </div>

        <div className="px-6 -mt-8 relative z-10 space-y-6">
           
           {/* Info Card */}
           <div className="bg-white rounded-2xl shadow-xl shadow-slate-200/50 p-6 border border-slate-50">
               <div className="flex items-start gap-4 mb-6 border-b border-slate-50 pb-6">
                   <div className="w-10 h-10 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                       <Clock className="w-5 h-5" />
                   </div>
                   <div>
                       <h3 className="font-bold text-slate-900 text-sm mb-1">开放时间</h3>
                       <p className="text-xs text-slate-500 leading-relaxed">
                           周二至周日 09:00-17:00<br/>
                           (16:30 停止入馆)<br/>
                           <span className="text-slate-400 text-[10px]">周一闭馆 (法定节假日除外)</span>
                       </p>
                   </div>
               </div>
               
               <div className="flex items-start gap-4">
                   <div className="w-10 h-10 rounded-full bg-orange-50 text-orange-600 flex items-center justify-center shrink-0">
                       <MapPin className="w-5 h-5" />
                   </div>
                   <div>
                       <h3 className="font-bold text-slate-900 text-sm mb-1">场馆地址</h3>
                       <p className="text-xs text-slate-500 leading-relaxed">
                           成都市天府大道北段966号<br/>
                           交子公园内
                       </p>
                   </div>
               </div>
           </div>

           {/* Booking Guide */}
           <div className="space-y-4">
               <h2 className="font-bold text-slate-900 text-lg flex items-center gap-2">
                   <span className="w-1 h-5 bg-slate-900 rounded-full"></span>
                   个人预约方式
               </h2>
               
               <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100 relative overflow-hidden">
                    <div className="relative z-10 flex gap-4">
                         {/* Mock QR Code */}
                        <div className="w-24 h-24 bg-white rounded-xl flex items-center justify-center border border-slate-200 shrink-0">
                            <Smartphone className="w-8 h-8 text-slate-300" />
                            <span className="sr-only">QR Code Placeholder</span>
                        </div>
                        <div className="flex flex-col justify-center">
                            <h3 className="font-bold text-slate-900 text-sm mb-2">关注微信公众号预约</h3>
                            <p className="text-xs text-slate-500 mb-3">搜索 "交子金融博物馆"</p>
                            <button className="px-4 py-1.5 bg-slate-900 text-white text-[10px] rounded-full w-fit font-medium">
                                复制公众号名称
                            </button>
                        </div>
                    </div>
                    {/* Decor */}
                    <div className="absolute top-0 right-0 w-32 h-32 bg-slate-200/20 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2"></div>
               </div>
           </div>

           {/* Group Booking */}
           <div className="space-y-4">
               <h2 className="font-bold text-slate-900 text-lg flex items-center gap-2">
                   <span className="w-1 h-5 bg-slate-900 rounded-full"></span>
                   团队预约
               </h2>
               <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-6 text-white shadow-lg shadow-blue-200">
                   <div className="flex justify-between items-start mb-4">
                       <div>
                           <h3 className="font-bold text-lg mb-1">团队参观通道</h3>
                           <p className="text-blue-100 text-xs">适用于企事业单位、学校等团体</p>
                       </div>
                       <Info className="w-5 h-5 text-blue-200" />
                   </div>
                   
                   <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-xl p-3 border border-white/10">
                       <Phone className="w-4 h-4 text-white" />
                       <span className="font-mono font-bold text-lg tracking-wide">028-6188 8888</span>
                   </div>
                   <p className="text-[10px] text-blue-100 mt-3 opacity-80">
                       * 请至少提前3个工作日致电预约
                   </p>
               </div>
           </div>

           {/* Tips */}
           <div className="bg-orange-50/50 rounded-xl p-4 border border-orange-100/50">
               <h4 className="text-orange-800 font-bold text-xs mb-2 flex items-center gap-1.5">
                   <Info className="w-3 h-3" /> 参观须知
               </h4>
               <ul className="text-[10px] text-orange-700/70 space-y-1.5 list-disc pl-4">
                   <li>入馆请出示本人身份证或预约二维码</li>
                   <li>请勿携带易燃易爆物品及宠物入馆</li>
                   <li>馆内请勿大声喧哗，禁止吸烟</li>
               </ul>
           </div>

        </div>
      </div>
    </MobileLayout>
  );
}
