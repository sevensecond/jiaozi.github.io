import MobileLayout from "@/components/layout/MobileLayout";
import { GraduationCap, LayoutTemplate, Gift, ArrowRight, Palette, Landmark, Presentation } from "lucide-react";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";
import museumImg from "@/assets/museum.jpg";

export default function Culture() {
  const [, setLocation] = useLocation();

  return (
    <MobileLayout activeTab="/culture" headerTitle="" hideTabBar={false}>
      <div className="h-full flex flex-col bg-slate-50">
        
        {/* Header */}
        <div className="px-6 pt-8 pb-6 flex justify-between items-end bg-white border-b border-slate-100 sticky top-0 z-20">
           <div>
              <div className="text-[10px] font-bold text-orange-500 tracking-widest uppercase mb-1">Services</div>
              <h1 className="text-2xl font-serif text-slate-900">文化服务体系</h1>
           </div>
           <div className="w-10 h-10 rounded-full bg-orange-50 border border-orange-100 flex items-center justify-center">
              <Palette className="w-5 h-5 text-orange-600" strokeWidth={1.5} />
           </div>
        </div>

        <div className="flex-1 overflow-y-auto pb-24 px-6 pt-6 space-y-8 no-scrollbar">
          
          {/* Core Feature: Museum */}
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
             <SectionHeader title="核心阵地" icon={Landmark} color="text-orange-600" />
             <FeaturedMuseumCard 
                title="交子金融博物馆"
                desc="全国首家以'交子'为主题的金融行业博物馆，坐落于交子公园内，是金融文化核心地标。"
                image={museumImg}
                onClick={() => setLocation("/culture/museum")}
             />
          </div>

          {/* Service Matrix */}
          <div className="space-y-4 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-100">
             <SectionHeader title="延伸服务" icon={Presentation} color="text-blue-600" />

            <ServiceCard 
                title="展陈服务"
                desc="提供文博展厅、党建阵地、企业展厅的全案策划与施工服务。"
                tag="20+ 精品项目"
                icon={LayoutTemplate}
                color="text-orange-600 bg-orange-50"
                onClick={() => setLocation("/culture/exhibition")}
            />
            
            <ServiceCard 
                title="会务研学"
                desc="承接高端会议、行业论坛，定制金融特色研学课程。"
                tag="500+ 场次"
                icon={GraduationCap}
                color="text-blue-600 bg-blue-50"
                onClick={() => setLocation("/culture/event")}
            />

            <ServiceCard 
                title="文创 IP 运营"
                desc="开发交子IP衍生品，提供商务礼品定制与品牌视觉设计。"
                icon={Gift}
                color="text-purple-600 bg-purple-50"
                onClick={() => setLocation("/culture/creative")}
            />
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}

function SectionHeader({ title, icon: Icon, color }: any) {
    return (
        <div className="flex items-center gap-2 mb-3 px-1">
            <Icon className={cn("w-4 h-4", color)} />
            <h2 className="text-sm font-bold text-slate-900 tracking-tight">{title}</h2>
        </div>
    )
}

function FeaturedMuseumCard({ title, desc, image, onClick }: any) {
    return (
       <div 
         onClick={onClick}
         className="relative w-full h-56 rounded-[1.5rem] overflow-hidden shadow-xl shadow-slate-200/50 group cursor-pointer active:scale-[0.98] transition-all duration-500"
       >
          <img src={image} alt={title} className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent"></div>
          
          <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-md border border-white/20 px-3 py-1 rounded-full text-white text-[10px] font-bold tracking-wider uppercase">
              National Base
          </div>

          <div className="absolute bottom-0 left-0 p-6 w-full">
             <h3 className="text-white text-xl font-serif mb-2">{title}</h3>
             <p className="text-white/80 text-xs font-light leading-relaxed line-clamp-2 mb-4">{desc}</p>
             <div className="flex items-center gap-2 text-orange-300 text-xs font-medium group-hover:gap-3 transition-all">
                 <span>了解详情</span>
                 <ArrowRight className="w-3.5 h-3.5" />
             </div>
          </div>
       </div>
    )
}

function ServiceCard({ title, desc, tag, icon: Icon, color, onClick }: any) {
   return (
      <div 
        className="bg-white rounded-[1.2rem] border border-slate-100 shadow-sm p-4 flex items-start gap-4 transition-all duration-300 hover:shadow-md active:scale-[0.98] cursor-pointer group"
        onClick={onClick}
      >
         <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-110", color)}>
            <Icon className="w-6 h-6" strokeWidth={1.5} />
         </div>
         <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-1">
              <h3 className="font-bold text-slate-900 text-sm">{title}</h3>
              {tag && <span className="text-[9px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">{tag}</span>}
            </div>
            <p className="text-xs text-slate-500 font-light leading-relaxed line-clamp-2">{desc}</p>
         </div>
         <div className="self-center">
             <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-slate-400" />
         </div>
      </div>
   )
}
