import MobileLayout from "@/components/layout/MobileLayout";
import { Building2, Layers } from "lucide-react";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";

// Import images
import tianfu9Img from "@/assets/tianfu-9.jpg";
import fintechImg from "@/assets/fintech-center.jpg";
import maitianImg from "@/assets/maitian.jpg";
import digitalImg from "@/assets/digital-center.jpg";


export default function Industry() {
  const [, setLocation] = useLocation();

  return (
    <MobileLayout activeTab="/industry" headerTitle="" hideTabBar={false}>
      <div className="h-full flex flex-col bg-gray-50/50">
        
        {/* Header */}
        <div className="px-6 pt-6 pb-4 flex justify-between items-end sticky top-0 bg-gray-50/80 backdrop-blur-xl z-20 border-b border-gray-200/50">
           <div>
              <h1 className="text-2xl font-light text-gray-900 tracking-tight">金融<br/><span className="font-bold">产业运营</span></h1>
           </div>
           <div className="w-10 h-10 rounded-full bg-white border border-gray-200 flex items-center justify-center">
              <Building2 className="w-5 h-5 text-blue-500" strokeWidth={1.5} />
           </div>
        </div>

        <div className="flex-1 overflow-y-auto pb-24 px-6 pt-4 space-y-5 no-scrollbar">
          <div className="space-y-5 animate-in fade-in slide-in-from-bottom-8 duration-700">
            <BusinessCard 
                title="天府国际金融中心9号楼" 
                desc="核心区高端办公空间，聚集持牌金融机构与总部企业。"
                tag="核心地标"
                image={tianfu9Img}
                delay={100}
                onClick={() => setLocation("/industry/tianfu")}
            />
            <BusinessCard 
                title="交子金融科技中心" 
                desc="专注金融科技孵化，配套完善的共享办公与路演大厅。"
                tag="国家级孵化器"
                image={fintechImg}
                delay={200}
                onClick={() => setLocation("/industry/fintech")}
            />
            <BusinessCard 
                title="金融麦田" 
                desc="创新与生态延展基地，适合成长型科技企业。"
                tag="生态园区"
                image={maitianImg}
                delay={300}
                onClick={() => setLocation("/industry/maitian")}
            />
            <BusinessCard 
                title="交子数智金融中心" 
                desc="聚焦数字货币与人工智能，打造前沿金融科技产业高地。"
                tag="数智高地"
                image={digitalImg}
                delay={400}
                onClick={() => setLocation("/industry/digital")}
            />

          </div>
        </div>
      </div>
    </MobileLayout>
  );
}

function BusinessCard({ title, desc, tag, image, delay, onClick }: any) {
   return (
      <div 
        onClick={onClick}
        className="group relative h-[200px] w-full rounded-[2rem] overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 cursor-pointer fill-mode-backwards active:scale-95"
        style={{ animationDelay: `${delay}ms` }}
      >
         <img src={image} alt={title} className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
         <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
         
         <div className="absolute bottom-0 left-0 w-full p-6 text-white translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
            <div className="flex items-center gap-2 mb-2">
               <span className="px-2 py-0.5 rounded-full bg-white/20 backdrop-blur-md border border-white/10 text-[10px] font-medium tracking-wide uppercase">{tag}</span>
            </div>
            <h3 className="font-bold text-xl mb-1">{title}</h3>
            <p className="text-xs text-white/70 line-clamp-2 opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">{desc}</p>
         </div>
      </div>
   )
}
