import MobileLayout from "@/components/layout/MobileLayout";
import { MapPin, Clock, Calendar, ChevronLeft, Ticket, Info, Star } from "lucide-react";
import { useLocation } from "wouter";
import museumImg from "@/assets/museum.jpg";

export default function MuseumDetail() {
  const [, setLocation] = useLocation();

  return (
    <MobileLayout activeTab="/culture" headerTitle="博物馆详情" hideTabBar={true} showBack={true}>
      <div className="min-h-full bg-white pb-24 relative">
        {/* Hero Section */}
        <div className="relative h-64 w-full">
            <img src={museumImg} className="w-full h-full object-cover" alt="交子金融博物馆" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
            <div className="absolute bottom-4 left-6 right-6">
                <span className="inline-block px-2 py-0.5 rounded-md bg-orange-500 text-white text-[10px] font-bold mb-2">国家级金融教育基地</span>
                <h1 className="text-2xl font-bold text-white mb-1">交子金融博物馆</h1>
                <p className="text-white/80 text-xs flex items-center gap-1">
                    <MapPin className="w-3 h-3" /> 成都市交子公园内
                </p>
            </div>
        </div>

        {/* Info Grid */}
        <div className="px-6 -mt-6 relative z-10">
            <div className="bg-white rounded-2xl shadow-lg p-5 grid grid-cols-2 gap-4 border border-gray-50">
                <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-1.5 text-gray-400">
                        <Clock className="w-3.5 h-3.5" />
                        <span className="text-[10px]">开放时间</span>
                    </div>
                    <p className="text-sm font-medium text-gray-900">09:00 - 17:00</p>
                    <p className="text-[10px] text-gray-400">16:00 停止入馆</p>
                </div>
                <div className="flex flex-col gap-1 border-l border-gray-100 pl-4">
                    <div className="flex items-center gap-1.5 text-gray-400">
                        <Calendar className="w-3.5 h-3.5" />
                        <span className="text-[10px]">闭馆安排</span>
                    </div>
                    <p className="text-sm font-medium text-gray-900">每周一闭馆</p>
                    <p className="text-[10px] text-gray-400">法定节假日另行通知</p>
                </div>
            </div>
        </div>

        {/* Content Sections */}
        <div className="px-6 mt-8 space-y-8">
            <section>
                <SectionTitle title="展馆特色" />
                <p className="text-sm text-gray-600 leading-relaxed mt-3 text-justify">
                    作为全国首家以“交子”为主题的金融行业博物馆，馆内珍藏了包括早期古代货币、川陕红色货币及世界各国纸币在内的 <span className="text-orange-600 font-bold">620余件</span> 珍贵藏品。通过体感互动、VR/AR等科技手段，生动再现了世界第一张纸币“交子”诞生的传奇历程。
                </p>
                <div className="flex gap-3 mt-4 overflow-x-auto no-scrollbar pb-2">
                    <Tag text="体感互动" />
                    <Tag text="AR/VR体验" />
                    <Tag text="交子印制" />
                    <Tag text="金融科普" />
                </div>
            </section>

            <section>
                <SectionTitle title="常设展览" />
                <div className="mt-4 space-y-3">
                    <ExhibitItem 
                        title="裂纸为币：交子的诞生" 
                        desc="回溯北宋时期交子诞生的历史背景与经济动因"
                    />
                    <ExhibitItem 
                        title="交行天下：纸币的发展" 
                        desc="展示纸币在不同历史时期的演变与全球影响"
                    />
                </div>
            </section>

             <section>
                <SectionTitle title="参观须知" />
                <div className="mt-3 bg-gray-50 rounded-xl p-4 text-xs text-gray-500 space-y-2">
                    <p>• 实行实名制预约参观，请提前在公众号预约</p>
                    <p>• 入馆请出示预约二维码或身份证</p>
                    <p>• 严禁携带易燃易爆物品及宠物入馆</p>
                </div>
            </section>
        </div>

        {/* Bottom Action */}
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-gray-100 flex gap-3 safe-area-bottom z-50">
            <button 
                onClick={() => setLocation("/visit")}
                className="flex-1 bg-gray-900 text-white font-bold h-12 rounded-xl flex items-center justify-center gap-2 active:scale-95 transition-transform shadow-xl shadow-gray-900/20"
            >
                <Ticket className="w-4 h-4" />
                查看预约指南
            </button>
        </div>
      </div>
    </MobileLayout>
  );
}

function SectionTitle({ title }: { title: string }) {
    return (
        <div className="flex items-center gap-2">
            <div className="w-1 h-4 bg-orange-500 rounded-full"></div>
            <h2 className="text-lg font-bold text-gray-900">{title}</h2>
        </div>
    )
}

function Tag({ text }: { text: string }) {
    return (
        <span className="px-3 py-1.5 bg-orange-50 text-orange-600 text-[10px] font-medium rounded-lg whitespace-nowrap">
            {text}
        </span>
    )
}

function ExhibitItem({ title, desc }: { title: string, desc: string }) {
    return (
        <div className="flex items-start gap-3 p-3 rounded-xl bg-white border border-gray-100 shadow-sm">
            <div className="w-8 h-8 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center shrink-0 mt-0.5">
                <Star className="w-4 h-4 fill-current" />
            </div>
            <div>
                <h3 className="text-sm font-bold text-gray-900">{title}</h3>
                <p className="text-xs text-gray-500 mt-1">{desc}</p>
            </div>
        </div>
    )
}
