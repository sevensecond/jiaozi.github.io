import MobileLayout from "@/components/layout/MobileLayout";
import { GraduationCap, Mic2, Check, ArrowRight } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

export default function ServiceEvent() {
  const [activeTab, setActiveTab] = useState("event"); // event | study

  return (
    <MobileLayout activeTab="/culture" headerTitle="会务与研学" hideTabBar={true} showBack={true}>
      <div className="min-h-full bg-slate-50 flex flex-col">
        
        {/* Top Toggle - Segmented Control */}
        <div className="px-6 py-4 bg-white border-b border-slate-100 sticky top-[44px] z-20">
            <div className="flex p-1 bg-slate-100 rounded-xl relative">
                <div className={cn(
                    "absolute top-1 bottom-1 w-[calc(50%-4px)] bg-white rounded-lg shadow-sm transition-all duration-300 ease-spring",
                    activeTab === "event" ? "left-1" : "left-[calc(50%+2px)]"
                )}></div>
                <TabButton 
                    active={activeTab === "event"} 
                    onClick={() => setActiveTab("event")}
                    label="会务服务"
                    icon={Mic2}
                />
                <TabButton 
                    active={activeTab === "study"} 
                    onClick={() => setActiveTab("study")}
                    label="金融研学"
                    icon={GraduationCap}
                />
            </div>
        </div>

        <div className="flex-1 px-6 py-6 space-y-8 pb-24">
            {activeTab === "event" ? <EventContent /> : <StudyContent />}
        </div>

      </div>
    </MobileLayout>
  );
}

function TabButton({ active, onClick, label, icon: Icon }: any) {
    return (
        <button 
            onClick={onClick}
            className={cn(
                "flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-bold transition-all duration-300 relative z-10",
                active ? "text-slate-900" : "text-slate-400 hover:text-slate-600"
            )}
        >
            <Icon className="w-4 h-4" />
            {label}
        </button>
    )
}

function EventContent() {
    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
            {/* Intro */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                <div className="flex items-center gap-2 mb-3">
                    <div className="w-1 h-4 bg-blue-600 rounded-full"></div>
                    <h3 className="font-bold text-slate-900 text-base">专业金融会务场馆</h3>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed text-justify mb-5">
                    依托交子金融梦工场优质载体，提供从小型商务洽谈到大型路演发布的全场景空间服务。
                </p>
                <div className="flex gap-4">
                     <div className="flex-1 bg-blue-50 rounded-xl p-3 text-center">
                        <div className="text-xl font-bold text-blue-600 font-mono">300<span className="text-xs">+</span></div>
                        <div className="text-[10px] text-blue-400">最大容纳(人)</div>
                     </div>
                     <div className="flex-1 bg-indigo-50 rounded-xl p-3 text-center">
                        <div className="text-xl font-bold text-indigo-600 font-mono">500<span className="text-xs">+</span></div>
                        <div className="text-[10px] text-indigo-400">服务场次</div>
                     </div>
                </div>
            </div>

            {/* Spaces */}
            <div className="space-y-3">
                <SectionHeader title="场地概览" />
                <SpaceCard 
                    title="超大型路演中心"
                    tags={["300人+", "专业音响", "高清大屏"]}
                    desc="适用于项目路演、产品发布会、大型论坛。"
                    theme="blue"
                />
                <SpaceCard 
                    title="智能会议室"
                    tags={["20-50人", "远程视频", "无纸化"]}
                    desc="适用于董事会、商务谈判、视频会议。"
                    theme="indigo"
                />
                <SpaceCard 
                    title="阳光多功能厅"
                    tags={["80-150人", "灵活布局", "自然采光"]}
                    desc="适用于培训讲座、沙龙分享、团建活动。"
                    theme="sky"
                />
            </div>
        </div>
    )
}

function StudyContent() {
    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
             {/* Banner */}
             <div className="bg-gradient-to-br from-orange-500 to-amber-500 rounded-2xl p-6 text-white shadow-lg shadow-orange-200">
                <div className="flex items-center gap-2 mb-2">
                    <GraduationCap className="w-5 h-5 text-white/90" />
                    <span className="font-bold tracking-wide text-sm opacity-90">交子金融研学</span>
                </div>
                <h3 className="text-2xl font-serif font-bold mb-2">沉浸式金融素养教育</h3>
                <p className="text-xs text-white/80 leading-relaxed font-light">
                    依托博物馆馆藏资源，打造集“看、听、学、玩”于一体的特色研学课程体系。
                </p>
            </div>

            {/* Courses */}
            <div className="space-y-3">
                <SectionHeader title="精品课程" />
                
                <CourseCard 
                    title="探秘交子·货币起源"
                    target="青少年"
                    tags={["历史文化", "手工体验", "财商启蒙"]}
                    desc="了解货币发展史，亲手体验交子印制，树立正确金钱观。"
                />
                
                <CourseCard 
                    title="金融普法·反诈课堂"
                    target="社区居民"
                    tags={["风险防范", "案例分析", "互动问答"]}
                    desc="识别非法集资与电信诈骗，守护钱袋子。"
                />

                <CourseCard 
                    title="红色金融·薪火相传"
                    target="企事业单位"
                    tags={["党史教育", "川陕苏区", "红色基因"]}
                    desc="回顾红色货币历史，感悟革命时期的金融智慧。"
                />
            </div>
        </div>
    )
}

function SectionHeader({ title }: { title: string }) {
    return (
        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest px-1">{title}</h4>
    )
}

function SpaceCard({ title, tags, desc, theme }: any) {
    const colors = {
        blue: "bg-blue-50 text-blue-600 border-blue-100",
        indigo: "bg-indigo-50 text-indigo-600 border-indigo-100",
        sky: "bg-sky-50 text-sky-600 border-sky-100",
    }
    
    return (
        <div className="bg-white rounded-xl p-4 shadow-sm border border-slate-100 flex gap-4">
            <div className={cn("w-1 self-stretch rounded-full", (colors as any)[theme].replace("border", "bg").split(" ")[2])}></div>
            <div className="flex-1">
                <h4 className="font-bold text-slate-900 mb-2 text-sm">{title}</h4>
                <div className="flex flex-wrap gap-1.5 mb-2">
                    {tags.map((t: string) => (
                        <span key={t} className="px-1.5 py-0.5 bg-slate-50 text-slate-500 text-[10px] rounded-md font-medium">{t}</span>
                    ))}
                </div>
                <p className="text-xs text-slate-400 leading-tight">{desc}</p>
            </div>
        </div>
    )
}

function CourseCard({ title, target, tags, desc }: any) {
    return (
        <div className="group bg-white p-4 rounded-xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex justify-between items-start mb-2">
                <h4 className="font-bold text-slate-900 text-sm">{title}</h4>
                <span className="text-[10px] text-orange-600 font-bold bg-orange-50 px-2 py-0.5 rounded-full">{target}</span>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed mb-3">{desc}</p>
            <div className="flex gap-3 pt-3 border-t border-slate-50">
                {tags.map((t: string) => (
                    <div key={t} className="flex items-center gap-1 text-[10px] text-slate-400">
                        <Check className="w-3 h-3 text-emerald-500" />
                        {t}
                    </div>
                ))}
            </div>
        </div>
    )
}
