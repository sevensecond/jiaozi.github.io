import MobileLayout from "@/components/layout/MobileLayout";
import { ShoppingBag, Stamp, PenTool, Sparkles, Trophy, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

export default function ServiceCreative() {
  return (
    <MobileLayout activeTab="/culture" headerTitle="文创运营" hideTabBar={true} showBack={true}>
      <div className="min-h-full bg-slate-50 pb-10">
        
        {/* Hero */}
        <div className="bg-purple-900 text-white pt-10 pb-16 px-6 relative overflow-hidden">
             <div className="relative z-10">
                 <h1 className="text-3xl font-serif italic mb-2 tracking-wide">Jiaozi<br/>Creative</h1>
                 <p className="text-purple-200 text-xs tracking-[0.3em] uppercase opacity-80">让金融文化触手可及</p>
             </div>
             {/* Decor */}
             <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-pink-500/20 to-purple-500/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
             <div className="absolute bottom-0 left-0 w-40 h-40 bg-indigo-500/20 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>
        </div>

        <div className="px-5 -mt-10 relative z-10 space-y-6">
            
            {/* Main Products */}
            <section className="grid grid-cols-2 gap-3">
                <ProductCard 
                    title="交子千年邮票" 
                    tag="联合发行" 
                    icon={Stamp}
                    color="text-red-500 bg-red-50"
                    desc="中国集邮总公司联合打造，珍藏级纪念邮票。"
                />
                <ProductCard 
                    title="碎钞工艺品" 
                    tag="独家专利" 
                    icon={Sparkles}
                    color="text-emerald-500 bg-emerald-50"
                    desc="创新运用人民币碎钞元素，寓意点石成金。"
                />
            </section>

            {/* Customization Service */}
            <section>
                <div className="bg-white border border-slate-100 shadow-xl shadow-slate-200/50 rounded-2xl p-6">
                    <div className="flex items-center gap-2 mb-6">
                        <div className="w-8 h-8 rounded-full bg-purple-50 flex items-center justify-center text-purple-600">
                            <PenTool className="w-4 h-4" />
                        </div>
                        <h2 className="font-bold text-slate-900">高端定制服务</h2>
                    </div>

                    <div className="space-y-6">
                        <ServiceItem 
                            title="商务礼品定制"
                            desc="为金融机构提供高端伴手礼、会议纪念品定制方案，融入企业文化元素。"
                        />
                        <div className="h-px bg-slate-50 w-full"></div>
                        <ServiceItem 
                            title="IP 授权与联名"
                            desc="开放“交子”博物馆IP授权，与品牌进行跨界联名，开发限定周边。"
                        />
                    </div>
                    
                    <button className="w-full mt-8 h-12 rounded-xl bg-purple-600 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-purple-200 active:scale-95 transition-all">
                        <ShoppingBag className="w-4 h-4" />
                        获取产品图册
                    </button>
                </div>
            </section>

            {/* Honors */}
            <section>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest px-1 mb-3">Honors & Awards</h4>
                <div className="space-y-2">
                    <HonorItem text="四川省博物馆“优秀文博科研成果”" />
                    <HonorItem text="四川省博物馆“文物IP授权优秀案例”" />
                    <HonorItem text="成都市特色旅游商品" />
                </div>
            </section>

        </div>
      </div>
    </MobileLayout>
  );
}

function ProductCard({ title, tag, desc, icon: Icon, color }: any) {
    return (
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex flex-col items-start h-full group hover:-translate-y-1 transition-transform duration-300">
            <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center mb-3", color)}>
                <Icon className="w-5 h-5" />
            </div>
            <div className="bg-slate-900 text-white text-[9px] px-1.5 py-0.5 rounded-md mb-2 font-bold">{tag}</div>
            <h3 className="font-bold text-slate-900 mb-1 text-sm">{title}</h3>
            <p className="text-[10px] text-slate-400 leading-tight">{desc}</p>
        </div>
    )
}

function ServiceItem({ title, desc }: any) {
    return (
        <div>
            <h3 className="font-bold text-slate-900 text-sm mb-1">{title}</h3>
            <p className="text-xs text-slate-500 leading-relaxed text-justify">{desc}</p>
        </div>
    )
}

function HonorItem({ text }: any) {
    return (
        <div className="flex items-center gap-3 p-3 bg-white rounded-xl text-xs text-slate-600 border border-slate-100 shadow-sm">
            <Trophy className="w-3.5 h-3.5 text-amber-500" />
            {text}
        </div>
    )
}
