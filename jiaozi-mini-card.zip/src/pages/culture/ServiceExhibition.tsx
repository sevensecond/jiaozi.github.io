import MobileLayout from "@/components/layout/MobileLayout";
import { LayoutTemplate, Sparkles, Ruler, CheckCircle2, ArrowRight } from "lucide-react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

export default function ServiceExhibition() {
  const [, setLocation] = useLocation();

  return (
    <MobileLayout activeTab="/culture" headerTitle="展陈服务" hideTabBar={true} showBack={true}>
      <div className="min-h-full bg-gray-50 pb-10">
        
        {/* Header Banner */}
        <div className="bg-gray-900 pt-8 pb-16 px-6 relative overflow-hidden">
            <div className="relative z-10">
                <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center mb-4 backdrop-blur-md border border-white/10">
                    <LayoutTemplate className="w-6 h-6 text-orange-400" />
                </div>
                <h1 className="text-2xl font-bold text-white mb-2">专业展陈全案服务</h1>
                <p className="text-white/60 text-xs leading-relaxed max-w-[80%]">
                    依托交子金融博物馆建设经验，提供从策划、设计、施工到运营的一站式展陈解决方案。
                </p>
            </div>
            
            {/* Background Decorations */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/20 blur-[80px] rounded-full pointer-events-none"></div>
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-blue-500/10 blur-[60px] rounded-full pointer-events-none"></div>
        </div>

        <div className="px-5 -mt-8 relative z-10 space-y-6">
            
            {/* Stats Card */}
            <div className="bg-white rounded-2xl p-6 shadow-lg shadow-gray-200/50 flex justify-between items-center">
                <StatItem num="20+" label="精品项目落地" />
                <div className="w-[1px] h-8 bg-gray-100"></div>
                <StatItem num="600+" label="展陈面积(㎡)" sub="(单体案例)" />
                <div className="w-[1px] h-8 bg-gray-100"></div>
                <StatItem num="100%" label="好评交付" />
            </div>

            {/* Service Scope */}
            <section>
                <SectionHeader title="服务领域" />
                <div className="grid grid-cols-3 gap-3 mt-4">
                    <ScopeCard title="文博展厅" desc="博物馆/纪念馆" color="bg-orange-50 text-orange-600" />
                    <ScopeCard title="党建阵地" desc="国企/机关党建" color="bg-red-50 text-red-600" />
                    <ScopeCard title="企业展厅" desc="品牌馆/荣誉室" color="bg-blue-50 text-blue-600" />
                </div>
            </section>

            {/* Featured Cases */}
            <section>
                <SectionHeader title="精品案例" />
                <div className="mt-4 space-y-4">
                    <CaseCard 
                        title="纪念纸币诞生千年展"
                        tag="精品临展"
                        specs="面积：612㎡ | 地点：交子金融博物馆"
                        desc="全案策划与施工。通过场景复原与多媒体互动，重现北宋街景与交子诞生历程。"
                    />
                    <CaseCard 
                        title="成渝双城经济圈建设展"
                        tag="主题展览"
                        specs="服务内容：策展设计、布展施工"
                        desc="高质量建设西部金融中心成果展示，融合现代科技感与金融稳重感。"
                    />
                     <CaseCard 
                        title="某大型国企党建中心"
                        tag="党建阵地"
                        specs="服务内容：空间规划、内容提炼"
                        desc="将红色文化与企业精神深度融合，打造沉浸式党性教育基地。"
                    />
                </div>
            </section>

            {/* Process */}
            <section className="pb-8">
                <SectionHeader title="服务流程" />
                <div className="mt-4 bg-white p-5 rounded-2xl border border-gray-100">
                    <div className="flex flex-col gap-6 relative">
                        {/* Connecting Line */}
                        <div className="absolute left-[15px] top-2 bottom-2 w-[2px] bg-gray-100"></div>
                        
                        <ProcessStep num="01" title="需求接洽" desc="深入沟通展陈目标、受众与预算" />
                        <ProcessStep num="02" title="策划设计" desc="空间规划、大纲撰写与效果图设计" />
                        <ProcessStep num="03" title="布展施工" desc="标准化施工管理与多媒体调试" />
                        <ProcessStep num="04" title="运营维护" desc="讲解培训、设备维护与内容更新" />
                    </div>
                </div>
            </section>

        </div>
        
        {/* Contact Button */}
        <div className="fixed bottom-6 right-6 z-30">
            <button 
                onClick={() => setLocation("/cooperation")}
                className="h-14 px-6 bg-gray-900 text-white rounded-full shadow-xl shadow-gray-900/30 flex items-center gap-2 font-bold active:scale-95 transition-transform"
            >
                <span className="text-sm">咨询合作</span>
                <ArrowRight className="w-4 h-4" />
            </button>
        </div>

      </div>
    </MobileLayout>
  );
}

function SectionHeader({ title }: { title: string }) {
    return (
        <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
            {title}
        </h2>
    )
}

function StatItem({ num, label, sub }: any) {
    return (
        <div className="flex flex-col items-center">
            <span className="text-xl font-bold text-gray-900 font-mono">{num}</span>
            <span className="text-[10px] text-gray-400 mt-0.5">{label}</span>
            {sub && <span className="text-[8px] text-gray-300 scale-90">{sub}</span>}
        </div>
    )
}

function ScopeCard({ title, desc, color }: any) {
    return (
        <div className={cn("p-3 rounded-xl flex flex-col items-center text-center gap-2", color)}>
            <div className="font-bold text-sm">{title}</div>
            <div className="text-[10px] opacity-70 leading-tight">{desc}</div>
        </div>
    )
}

function CaseCard({ title, tag, specs, desc }: any) {
    return (
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm">
            <div className="flex justify-between items-start mb-2">
                <h3 className="font-bold text-gray-900 text-base">{title}</h3>
                <span className="px-2 py-0.5 bg-gray-100 text-gray-500 text-[10px] rounded-md font-medium">{tag}</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-orange-600 mb-3 bg-orange-50/50 p-2 rounded-lg w-fit">
                <Ruler className="w-3.5 h-3.5" />
                <span>{specs}</span>
            </div>
            <p className="text-xs text-gray-500 leading-relaxed text-justify">
                {desc}
            </p>
        </div>
    )
}

function ProcessStep({ num, title, desc }: any) {
    return (
        <div className="flex gap-4 relative z-10">
            <div className="w-8 h-8 rounded-full bg-white border-2 border-orange-500 text-orange-500 font-bold text-xs flex items-center justify-center shrink-0 shadow-sm">
                {num}
            </div>
            <div>
                <h4 className="font-bold text-gray-900 text-sm">{title}</h4>
                <p className="text-xs text-gray-400 mt-1">{desc}</p>
            </div>
        </div>
    )
}
