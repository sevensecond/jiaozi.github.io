import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Router, Route, Switch } from "wouter";
import { useHashLocation } from "wouter/use-hash-location";
import ErrorBoundary from "@/components/ErrorBoundary";
import { ThemeProvider } from "@/contexts/ThemeContext";
import Home from "@/pages/Home";
import Group from "@/pages/Group";
import Industry from "@/pages/Industry";
import TianfuDetail from "@/pages/industry/TianfuDetail";
import FintechDetail from "@/pages/industry/FintechDetail";
import MaitianDetail from "@/pages/industry/MaitianDetail";
import DigitalDetail from "@/pages/industry/DigitalDetail";
import Culture from "@/pages/Culture";
import MuseumDetail from "@/pages/culture/MuseumDetail";
import ServiceExhibition from "@/pages/culture/ServiceExhibition";
import ServiceEvent from "@/pages/culture/ServiceEvent";
import ServiceCreative from "@/pages/culture/ServiceCreative";
import Cooperation from "@/pages/Cooperation";
import Visit from "@/pages/Visit";
import Venue from "@/pages/Venue";
import NotFound from "@/pages/NotFound";

function AppRouter() {
  return (
    <Router hook={useHashLocation}>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/group" component={Group} />
        <Route path="/industry" component={Industry} />
        <Route path="/industry/tianfu" component={TianfuDetail} />
        <Route path="/industry/fintech" component={FintechDetail} />
        <Route path="/industry/maitian" component={MaitianDetail} />
        <Route path="/industry/digital" component={DigitalDetail} />
        <Route path="/culture" component={Culture} />
        <Route path="/culture/museum" component={MuseumDetail} />
        <Route path="/culture/exhibition" component={ServiceExhibition} />
        <Route path="/culture/event" component={ServiceEvent} />
        <Route path="/culture/creative" component={ServiceCreative} />
        
        <Route path="/cooperation" component={Cooperation} />
        <Route path="/visit" component={Visit} />
        <Route path="/venue" component={Venue} />
        <Route component={NotFound} />
      </Switch>
    </Router>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <AppRouter />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
